<?php

declare(strict_types=1);

namespace App\Core\Export\Services;

use App\Core\Export\Data\PdfDocument;
use App\Core\Export\Data\SpreadsheetDocument;
use App\Core\Export\Data\SpreadsheetSheet;

final class StructuredResultExportFactory
{
    /** @param array<string,mixed> $result @param array<string,mixed> $input */
    public function pdf(string $title, string $filename, array $result, array $input = []): PdfDocument
    {
        return new PdfDocument($filename, 'exports.structured-result', compact('title', 'result', 'input'));
    }

    /** @param array<string,mixed> $result @param array<string,mixed> $input */
    public function spreadsheet(string $filename, array $result, array $input = []): SpreadsheetDocument
    {
        $sheets = [new SpreadsheetSheet('Resultado', $this->rows($result))];
        if ($input !== []) $sheets[] = new SpreadsheetSheet('Dados informados', $this->rows($input));
        return new SpreadsheetDocument($filename, $sheets);
    }

    /** @param array<string,mixed> $data @return list<list<string|int|float|bool|null>> */
    private function rows(array $data): array
    {
        $rows = [['Campo', 'Valor']];
        $walk = function (array $values, string $prefix = '') use (&$walk, &$rows): void {
            foreach ($values as $key => $value) {
                $path = $prefix === '' ? (string) $key : $prefix.'.'.$key;
                if (is_array($value)) { $walk($value, $path); continue; }
                $rows[] = [$path, is_scalar($value) || $value === null ? $value : json_encode($value, JSON_UNESCAPED_UNICODE)];
            }
        };
        $walk($data);
        return $rows;
    }
}
