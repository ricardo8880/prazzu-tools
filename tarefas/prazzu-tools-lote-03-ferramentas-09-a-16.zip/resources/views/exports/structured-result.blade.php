<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><style>
@page{margin:18mm}body{font-family:DejaVu Sans,sans-serif;font-size:10px;color:#111}h1{font-size:18px;margin:0 0 16px}h2{font-size:13px;margin:18px 0 6px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #bbb;padding:5px;text-align:left;vertical-align:top}th{background:#eee;width:38%}
</style></head><body><h1>{{ $title }}</h1>
@if($input !== [])<h2>Dados informados</h2><table>@foreach($input as $key=>$value)<tr><th>{{ $key }}</th><td>{{ is_array($value) ? json_encode($value, JSON_UNESCAPED_UNICODE) : $value }}</td></tr>@endforeach</table>@endif
<h2>Resultado</h2><table>@foreach($result as $key=>$value)<tr><th>{{ $key }}</th><td>{{ is_array($value) ? json_encode($value, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT) : $value }}</td></tr>@endforeach</table></body></html>
