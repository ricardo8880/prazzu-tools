<?php

declare(strict_types=1);

it('registers pdf and excel exports for official tools nine through sixteen', function (): void {
    $routes = collect(app('router')->getRoutes())->map(fn ($route) => $route->getName())->filter();
    foreach ([
        'tools.ponto-de-equilibrio', 'tools.calculadora-margem-markup', 'tools.simulador-pro-labore-ideal',
        'tools.comissao-vendedores', 'tools.gerador-holerite', 'tools.simulador-admissao',
        'tools.calculadora-de-rescisao', 'tools.reajuste-salarial',
    ] as $name) {
        expect($routes->contains($name.'.export.pdf') || ($name === 'tools.calculadora-margem-markup' && $routes->contains($name.'.export.pdf')) || ($name === 'tools.calculadora-de-rescisao' && $routes->contains($name.'.export')))->toBeTrue();
        expect($routes->contains($name.'.export.excel') || ($name === 'tools.calculadora-margem-markup' && $routes->contains($name.'.export')))->toBeTrue();
    }
});
