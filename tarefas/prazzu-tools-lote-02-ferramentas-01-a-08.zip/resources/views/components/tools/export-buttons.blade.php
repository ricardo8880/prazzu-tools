@props(['pdfRoute', 'excelRoute', 'input' => []])
@php
$renderInputs = function (array $values, string $prefix = '') use (&$renderInputs): string {
    $html = '';
    foreach ($values as $key => $value) {
        $name = $prefix === '' ? (string) $key : $prefix.'['.$key.']';
        if (is_array($value)) {
            $html .= $renderInputs($value, $name);
            continue;
        }
        if ($value === null) {
            continue;
        }
        $html .= '<input type="hidden" name="'.e($name).'" value="'.e((string) $value).'">';
    }
    return $html;
};
@endphp
<div class="d-flex flex-wrap gap-2 mt-3" data-result-export-actions>
    <form method="POST" action="{{ $pdfRoute }}">
        @csrf
        {!! $renderInputs($input) !!}
        <button type="submit" class="btn btn-outline-danger">Baixar PDF</button>
    </form>
    <form method="POST" action="{{ $excelRoute }}">
        @csrf
        {!! $renderInputs($input) !!}
        <button type="submit" class="btn btn-outline-success">Baixar Excel</button>
    </form>
</div>
