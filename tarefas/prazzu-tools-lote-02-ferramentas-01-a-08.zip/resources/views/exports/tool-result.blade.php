<!doctype html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">
    <style>
        @page { margin: 18mm; }
        body { font-family: DejaVu Sans, sans-serif; font-size: 10px; color: #111; }
        h1 { font-size: 18px; margin: 0 0 14px; }
        h2 { font-size: 13px; margin: 18px 0 7px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #bbb; padding: 6px; vertical-align: top; }
        th { background: #eee; text-align: left; }
        .value { text-align: right; white-space: nowrap; }
        .note { color: #444; font-size: 9px; }
    </style>
</head>
<body>
<h1>{{ $title }}</h1>

<h2>Resumo</h2>
<table>
    <thead><tr><th>Indicador</th><th>Valor</th><th>Descrição</th></tr></thead>
    <tbody>
    @foreach (($result['summary'] ?? []) as $item)
        <tr><td>{{ $item['label'] ?? $item['key'] ?? '' }}</td><td class="value">{{ $item['value'] ?? '' }}</td><td>{{ $item['description'] ?? '' }}</td></tr>
    @endforeach
    </tbody>
</table>

@if ($input !== [])
<h2>Dados informados</h2>
<table><tbody>
@foreach ($input as $key => $value)
<tr><th>{{ $key }}</th><td>{{ is_array($value) ? json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : $value }}</td></tr>
@endforeach
</tbody></table>
@endif

@if (!empty($result['details']))
<h2>Detalhamento</h2>
<table><tbody>
@foreach ($result['details'] as $key => $value)
<tr><th>{{ $key }}</th><td>{{ is_array($value) ? json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : $value }}</td></tr>
@endforeach
</tbody></table>
@endif

@if (!empty($result['calculation_memory']['steps']))
<h2>Memória de cálculo</h2>
<table>
<thead><tr><th>Etapa</th><th>Fórmula</th><th>Resultado</th></tr></thead>
<tbody>
@foreach ($result['calculation_memory']['steps'] as $step)
<tr><td>{{ $step['label'] ?? '' }}</td><td>{{ $step['formula'] ?? '' }}</td><td class="value">{{ $step['result'] ?? '' }}</td></tr>
@endforeach
</tbody>
</table>
@endif

@if (!empty($result['warnings']))
<h2>Alertas do resultado</h2>
@foreach ($result['warnings'] as $warning)
<p class="note">{{ $warning['message'] ?? $warning['label'] ?? json_encode($warning, JSON_UNESCAPED_UNICODE) }}</p>
@endforeach
@endif
</body>
</html>
